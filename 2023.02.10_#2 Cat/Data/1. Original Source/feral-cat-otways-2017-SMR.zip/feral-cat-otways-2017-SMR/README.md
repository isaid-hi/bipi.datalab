# feral-cat-otways-2017-SMR
Data and code for spatial mark-resight analysis (sighting-only) of feral cats for https://doi.org/10.1016/j.biocon.2019.108287

In "orginal_analysis" you will find the data / original code used for the above manuscript. 
In "updated_analyis" you will find an updated version of the code (fixed an error in the handling of tn / tm cats [did not impact results], and some minor changes due to updated secr version and to make more efficient code / helpful comments). 

This data / code is avaiable online at: https://github.com/matt-w-rees/feral-cat-otways-2017-SMR
